/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.mydemo.controller;

/**
 *
 * @author user
 */
import com.example.mydemo.exception.ResourceNotFoundException;
import com.example.mydemo.model.Supplier;
import com.example.mydemo.repository.SupplierRepository;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api/v1")
public class SupplierController {
 
    @Autowired
    private SupplierRepository supplierRepository;

    @GetMapping("/suppliers")
    public List<Supplier> getAllUsers() {
        return supplierRepository.findAll();
    }

    @GetMapping("/suppliers/{id}")
    public ResponseEntity<Supplier> getUserById(
    @PathVariable(value = "id") Long userId) throws ResourceNotFoundException {
        Supplier user = supplierRepository.findById(userId)
        .orElseThrow(() -> new ResourceNotFoundException("Supplier not found on :: "+ userId));
        return ResponseEntity.ok().body(user);
    }

    @PostMapping("/suppliers")
    public Supplier createUser(@Valid @RequestBody Supplier user) {
        return supplierRepository.save(user);
    }

    @PutMapping("/suppliers/{id}")
    public ResponseEntity<Supplier> updateUser(
    @PathVariable(value = "id") Long userId,
    @Valid @RequestBody Supplier userDetails) throws ResourceNotFoundException {
         Supplier user = supplierRepository.findById(userId)
          .orElseThrow(() -> new ResourceNotFoundException("supplier not found on :: "+ userId));
  
        user.setCompanyName(userDetails.getCompanyName());
        user.setVatNumber(userDetails.getVatNumber());
        user.setLastName(userDetails.getLastName());
        user.setFirstName(userDetails.getFirstName());
        user.setIrsOffice(userDetails.getIrsOffice());
        user.setAddress(userDetails.getAddress());
        user.setZipCode(userDetails.getZipCode());
        user.setCity(userDetails.getCity());
        user.setCountry(userDetails.getCountry());
        
        final Supplier updatedUser = supplierRepository.save(user);
        return ResponseEntity.ok(updatedUser);
   }

   @DeleteMapping("/suppliers/{id}")
   public Map<String, Boolean> deleteUser(
       @PathVariable(value = "id") Long userId) throws Exception {
       Supplier user = supplierRepository.findById(userId)
          .orElseThrow(() -> new ResourceNotFoundException("Supplier not found on :: "+ userId));

       supplierRepository.delete(user);
       Map<String, Boolean> response = new HashMap<>();
       response.put("deleted", Boolean.TRUE);
       return response;
   }
}
